export function calculateResult(path, answers) {
  let res = "";
  let code = null;

  // ========= CONSULT (vaste patiënt) =========
  if (path === "Consult") {
    // Let op: indices na toevoegen van de 1e vraag ("vaste patiënt?")
    const vastePatient = answers[0];                 // "Ja" of "Nee" 
    const hulpvraag = answers[1];                    // "Ja"/"Nee"
    const professioneelAntwoord = answers[2];        // "Ja"/"Nee"
    const vanuitPraktijk = answers[3];               // "Ja"/"Nee"
    const duur = answers[4];                         // "< 5 minuten" | "5–20 minuten" | "20 minuten of langer"
    const typeConsult = answers[5];                  // "Fysiek consult" | "Telefonisch consult" | "E-consult"
    const mni = answers[6];                          // "Ja"/"Nee" (kan undefined zijn bij telefon./e-consult)
    const verrichting = answers[7];                  // string (alleen als mni "Ja")

    // Basiscriteria
    if (
      hulpvraag !== "Ja" ||
      professioneelAntwoord !== "Ja" ||
      vanuitPraktijk !== "Ja"
    ) {
      return { res: "Niet declarabel", code: [] };
    }

    // Basis: duur
    if (duur === "< 5 minuten") {
      res = "Kort consult";
      code = "C001";
    } else if (duur === "5–20 minuten") {
      res = "Standaard consult";
      code = "C002";
    } else if (duur === "20 minuten of langer") {
      res = "Lang consult";
      code = "C003";
    } else {
      res = "Consult";
      code = "C000";
    }

    // Type
    if (typeConsult === "Telefonisch consult") {
      res += " (telefonisch)";
    } else if (typeConsult === "E-consult") {
      res += " (e-consult)";
    }

    // M&I (alleen fysiek + "Ja")
    if (typeConsult === "Fysiek consult" && mni === "Ja") {
      res += " + M&I-verrichting";
      if (Array.isArray(code)) {
        code.push("MI001");
      } else if (code) {
        code = [code, "MI001"];
      } else {
        code = ["MI001"];
      }
    }

    return { res, code: Array.isArray(code) ? code : code ? [code] : [] };
  }

  // ========= CONSULT (niet-vast) =========
  if (path === "ConsultNietVast") {
    const typePatient = answers[0]; // "Toerist" | "Asielzoeker" | "Onverzekerd"
    const spoed = answers[1];       // "Ja"/"Nee"

    if (typePatient === "Toerist") {
      res = "Consult toerist";
      code = "C100";
    } else if (typePatient === "Asielzoeker") {
      res = "Consult asielzoeker";
      code = "C101";
    } else if (typePatient === "Onverzekerd") {
      res = "Consult onverzekerde patiënt";
      code = "C102";
    } else {
      res = "Consult niet-vaste patiënt";
      code = "C199";
    }

    if (spoed === "Ja") {
      res += " (spoed)";
      code = Array.isArray(code) ? [...code, "S001"] : [code, "S001"];
    }

    return { res, code: Array.isArray(code) ? code : code ? [code] : [] };
  }

  // ========= VISITE =========
  if (path === "Visite") {
    const thuis = answers[0]; 
    const duur = answers[1];  
    const type = answers[2];  

    if (thuis !== "Ja") return { res: "Niet declarabel", code: [] };

    if (type === "Intensieve zorg") {
      return { res: "Visite intensieve zorg", code: ["V100"] };
    }
    if (type === "ELV") {
      return { res: "Visite ELV", code: ["V101"] };
    }

    if (duur === "≥ 20 minuten") {
      return { res: "Visite lang", code: ["V002"] };
    }
    return { res: "Visite", code: ["V001"] };
  }

  // ========= M&I- VERRICHTING =========
  if (path === "M&I-verrichting") {
    const medischeVerrichting = answers[0]; 
    const verrichting = answers[1];         

    if (medischeVerrichting === "Ja") {
      return { res: `M&I-verrichting: ${verrichting}`, code: ["MI001"] };
    }
    return { res: "Geen M&I-verrichting declarabel", code: [] };
  }

  // ========= FALLBACK =========
  return { res: "Geen resultaat gevonden", code: [] };
}
