declare module "./ProgressBar" {
  const ProgressBar: React.FC<any>; // Dit vertelt TypeScript dat ProgressBar een React functionele component is
  export default ProgressBar;
}
