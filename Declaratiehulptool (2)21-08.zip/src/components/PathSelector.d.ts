declare module "./PathSelector" {
  const PathSelector: React.FC<any>; // Dit vertelt TypeScript dat PathSelector een React-functionele component is
  export default PathSelector;
}
