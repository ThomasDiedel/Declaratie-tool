declare module "./calculateResult" {
  export function calculateResult(
    path: string,
    answers: string[],
    stripped: string
  ): string;
}
