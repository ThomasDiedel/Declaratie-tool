export const tableData = [
  { code: "1201", omschrijving: "Consult kort", verrichting: "CK" },
  { code: "1202", omschrijving: "Consult normaal", verrichting: "CN" },
  { code: "1203", omschrijving: "Consult lang", verrichting: "C2" },
  { code: "1301", omschrijving: "Visite regulier", verrichting: "V" },
  { code: "1302", omschrijving: "Visite lang", verrichting: "V2" },
  { code: "1401", omschrijving: "CRP-test", verrichting: "CRPC" },
  { code: "1402", omschrijving: "Wondverzorging", verrichting: "M&I" },
  { code: "1403", omschrijving: "Injectie", verrichting: "INJ" },
];
